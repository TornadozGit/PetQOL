<nav class="bottom-nav d-lg-none">
    <button class="nav-btn active" onclick="app.navigate('dashboard')"><i class="bi bi-speedometer2"></i><span>Home</span></button>
    <button class="nav-btn" onclick="app.navigate('pets')"><i class="fa-solid fa-paw"></i><span>Pets</span></button>
    <div class="nav-action"><button class="btn btn-primary btn-icon shadow-lg" onclick="app.navigate('checkin')"><i class="bi bi-plus-lg"></i></button></div>
    <button class="nav-btn" onclick="app.navigate('history')"><i class="bi bi-clock-history"></i><span>History</span></button>
    <button class="nav-btn" onclick="app.navigate('insights')"><i class="bi bi-graph-up-arrow"></i><span>Insights</span></button>
</nav>